%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-02-04T13:29:37+01:00*%
%TF.ProjectId,testproj,74657374-7072-46f6-9a2e-6b696361645f,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-02-04 13:29:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.150000X-0.587500X-0.150000X0.587500X-0.150000X0.587500X0.150000X-0.587500X0.150000X0*%
%ADD11C,1.400000*%
%ADD12RoundRect,0.770000X-0.980000X-0.980000X0.980000X-0.980000X0.980000X0.980000X-0.980000X0.980000X0*%
%ADD13C,3.500000*%
%ADD14RoundRect,0.261500X-0.261500X-0.476500X0.261500X-0.476500X0.261500X0.476500X-0.261500X0.476500X0*%
G04 APERTURE END LIST*
D10*
%TO.C,Q1*%
X135062500Y-128650000D03*
X135062500Y-130550000D03*
X136937500Y-129600000D03*
%TD*%
D11*
%TO.C,J1*%
X131900000Y-114700000D03*
X142900000Y-114700000D03*
D12*
X134900000Y-119700000D03*
D13*
X139900000Y-119700000D03*
%TD*%
D14*
%TO.C,D1*%
X134870000Y-133360000D03*
X136750000Y-133360000D03*
%TD*%
M02*
